#ifndef ITERATOR_H
#define ITERATOR_H

#include "elasticnet.h"


// Virtual class to be inherited from
class Iterable{

public:
    virtual void apply() = 0;

};

// Implements the apply-function to solve the net
class Iterator : public Iterable{

private:

    // Properties of the iterator
    int iterMax; // Maximum of iterations
    int iterCounter; // Current iteration counter (n)
    double etaTarget; // Precision target
    double currentTemperature; // K(n) parameter
    double initialTemperature; // K(0) parameter
    double alpha; // Alpha parameter
    double beta; // Beta parameter
    ElasticNet *net; // Pointer on given net - changes are global!

public:

    // Constructors
    Iterator();
    Iterator(ElasticNet *net, double alpha, double beta, double temperature);
    Iterator(ElasticNet *net);

    // Set current iteration n (used to reset the iterator)
    void setIterCounter(int iterCounter);
    // Calculate and set the current temperature K(n)
    void setCurrentTemperature();
    void setNet(ElasticNet *net);

    // Getters for parameters
    double getInitialTemperature();
    double getCurrentTemperature();
    double getT();
    double getIterMax();
    double getAlpha();
    double getBeta();
    double getEtaTarget();

    //Setter
    void setInitialTemperature(double temp);
    void setIterMax(int iterMax);
    void setAlpha(double alpha);
    void setBeta(double beta);
    void setEtaTarget(double eta);

    // Return the net
    ElasticNet* getNet();

    // Calculate the current precision
    double calcEta();

    void apply();
    void solve();
};

#endif
