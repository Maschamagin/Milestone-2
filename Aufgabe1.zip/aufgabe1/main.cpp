#include "ElasticNet.h"
#include <iostream>
#include "Point.h"
#include "Iterator.h"

using namespace std;

int main(){

    //generate a Elastic Net and add Citys manually
    ElasticNet net;

    net.addCity(0.23,0.04);
    net.addCity(0.57,0.38);
    net.addCity(0.89,0.01);


    //print the cities positions in the console
    cout << "Cities: " << endl;
    vector<Point> test = net.getCities();
    for(vector<Point>::iterator i = test.begin(); i != test.end(); ++i){
        cout << i->x << " " << i->y << endl;
    }

    //print the nodes' positions in the console
    cout << "Nodes: " << endl;
    vector<Point> testnodes = net.getNodes();
    for(vector<Point>::iterator j = testnodes.begin(); j != testnodes.end(); ++j){
        cout << j->x << " " << j->y << endl;
    }


    //generate an iterator object
    Iterator iterator(&net);

    //solve the net
    cout << "_____________________solve_________________" << endl;
    iterator.solve();

    //print the solved net
    cout << "\n_____________________\n";
    cout << "Nodes: " << endl;
    vector<Point> testnodes2 = net.getNodes();
    for(vector<Point>::iterator j = testnodes2.begin(); j != testnodes2.end(); ++j){
        cout << j->x << " " << j->y << endl;
    }



    return 0;
}
